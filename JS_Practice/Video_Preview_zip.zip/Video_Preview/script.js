console.log("page loaded...");

var vid = document.getElementById("sampleVid")

function previewVid() {
    vid.play();
}

function pauseVid() {
    vid.pause();
}

